from os import system, name
from time import sleep
import requests
import json 
import html
import time

#catagory 15 is entertainment and gatgory 18 is Scienc: computers catagory and 9 is general knowlege 21 is sports
#custom_quiz = [["Custom selections:",["Catagory: ","Science: Computers","Entertainment: Video Games","General Knowledge"]],["Difficulty: ",["easy","medium","hard","any"]],["Type: ",["multiple","boolean","either"]]]
catagory = ("&catagory=15")
difficulty = ("&difficulty=easy")

name_list =[]

def clear():
    if name == 'nt':
        os = system('cls')
    else:
        os = system('clear')
 
def question_grabber(catagory,difficulty):
    url = "https://opentdb.com/api.php?amount=10"
    response = requests.get((url)+str(catagory)+str(difficulty))
    api_data = json.loads(response.text)
    make_json = open('questions.json','w')
    make_json.write(json.dumps(api_data, ensure_ascii=False, indent = 4))

def how_many_playing():
    user_amount = int(input('how many users are playing: '))
    #user_amount -=1
    def name_asking():
        username = input('what your name: ')
        name_list.append([username])
    for number in range(int(user_amount)):
        name_asking()

class Active_user:
    name = None
    correct = 0
    incorrect = 0

class Game:
    user_array=[]


    def add_users(self,data_list:list=None,usernames:list=None) -> None:

        if data_list:
            user_amount = len(data_list)
        else:
            user_amount = len(usernames)
        
        for x in range(user_amount):  
            user = Active_user()
            if data_list != None:
                data = data_list[x]
                user.name=data.get('name')
                user.correct=data.get('correct')
                user.incorrect=data.get('incorrect')
            else:
                user.name=usernames[x]

            self.user_array.append(user)

    def clear_users(self):
        self.user_array.clear()
users = Game().user_array

def question_function(): 
            number_questions = 0
            with open('questions.json') as json_file:
               questions = json.load(json_file)  
               for question in questions["results"]:
                   number_questions +=1
                   time.sleep(1)
                   clear()
                   print("questions number: "+str(number_questions))
                   print(html.unescape(question["question"]))
                   print(html.unescape("Options:"))
                   for i in range(len(question["incorrect_answers"])):
                       print(html.unescape(f"{i+1}. {question['incorrect_answers'][i]}"))
                   print(html.unescape(f"{len(question['incorrect_answers'])+1}. {question['correct_answer']}"))
                   user_answer = int(input("Enter the number of your answer: "))
                   if user_answer == len(question["incorrect_answers"]) + 1:
                       print("Correct!")
                   else:
                       print("Incorrect.") 

how_many_playing()
 

Game().clear_users()
Game().add_users(usernames=name_list)

for user in users:
    print(user.name)
    user.correct+=5
    print(user.correct)
    print(user.incorrect)



