from os import system, name
from time import sleep
import requests
import json 
import html
import time
import random

#catagory 15 is entertainment and gatgory 18 is Scienc: computers catagory and 9 is general knowlege 21 is sports
#custom_quiz = [["Custom selections:",["Catagory: ","Science: Computers","Entertainment: Video Games","General Knowledge"]],["Difficulty: ",["easy","medium","hard","any"]],["Type: ",["multiple","boolean","either"]]]
catagory = ("&catagory=15")
difficulty = ("&difficulty=easy")

name_list =[]

def clear():
    if name == 'nt':
        os = system('cls')
    else:
        os = system('clear')

def input_function(range):
    while True:
        try:
            choice = int(input())
            if choice > 0 and choice <= range:
                return choice
            else:
                print("Pick a number in Range Please")
        except:
            print("Only Awnser Using Numbers")

def question_grabber(catagory,difficulty):
    url = "https://opentdb.com/api.php?amount=10"
    response = requests.get((url)+str(catagory)+str(difficulty))
    api_data = json.loads(response.text)
    make_json = open('questions.json','w')
    make_json.write(json.dumps(api_data, ensure_ascii=False, indent = 4))

def how_many_playing():
    user_amount = int(input('how many users are playing: '))
    #user_amount -=1
    def name_asking():
        username = input('what your name: ')
        name_list.append(username)
    for number in range(int(user_amount)):
        name_asking()

class Active_user:
    name = None
    correct = 0
    incorrect = 0

class Game:
    user_array=[]


    def add_users(self,data_list:list=None,usernames:list=None) -> None:

        if data_list:
            user_amount = len(data_list)
        else:
            user_amount = len(usernames)
        
        for x in range(user_amount):  
            user = Active_user()
            if data_list != None:
                data = data_list[x]
                user.name=data.get('name')
                user.correct=data.get('correct')
                user.incorrect=data.get('incorrect')
            else:
                user.name=usernames[x]

            self.user_array.append(user)

    def clear_users(self):
        self.user_array.clear()


def read_data_file(name,filetype='.json'):
    return json.loads(open(name+filetype, "r").read())

def question_function(questions,users): 
    for user in users:
        for counter,  question in enumerate(questions , start=1):
            clear()
            print(user.name +'\n')
            print("questions "+str(counter) + ' of ' + str(len(questions))+'\n')
            print(html.unescape(question["question"])+'\n')
            print("Options:")

            choices = [x for x in question["incorrect_answers"]]
            choices.append(question['correct_answer'])
            random.shuffle(choices)

            for id , items in enumerate(choices, start=1):
                print(str(id) + ' ' + items)
            print('\n')
            user_answer = input_function(len(choices))
            user_answer-=1

            if choices[user_answer] == question['correct_answer']:
                print("Correct!")
                user.correct+=1
            else:
                print("Incorrect. Answer was " + question['correct_answer']) 
                user.incorrect+=1
            time.sleep(1)
        print('result')
        print('name '+user.name)
        print('correct '+str(user.correct))
        print('Incorrect '+str(user.incorrect))
        time.sleep(1)
    clear()
    print("Final score\n")
    for user in users:
        print('name '+user.name)
        print('correct '+str(user.correct))
        print('Incorrect '+str(user.incorrect))
        print('\n')


questions = read_data_file('questions')["results"]

how_many_playing() 

Game().add_users(usernames=name_list)

users = Game().user_array

question_function(questions,users)


