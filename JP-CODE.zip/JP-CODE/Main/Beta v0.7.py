from os import system, name
from time import sleep
import requests
import json 
import html
import time
import random
import socket

name_list =[]
response = []

#This is a function i made that has clear screen support on windows and Mac OS.
def clear():
    if name == 'nt':
        os = system('cls')
    else:
        os = system('clear')

#This is a funtions i used to print list's it prints them in a numbered fashion.
def list_print(array_name):
    for id , items in enumerate(array_name, start=1):
        print(str(id) + ' ' + items)
    print('\n')

#instead of me having to type in the ranges and error checking on every input i use this function instead it works way better.
def input_function(range):
    while True:
        try:
            choice = int(input())
            if choice > 0 and choice <= range:
                return choice
            else:
                print("Pick a number in Range Please")
        except:
            print("Only Awnser Using Numbers")

#This function is the function i use to put all the users requests into the url and then create a json folder for it.
def question_grabber(catagory,difficulty,question_type):
    url = "https://opentdb.com/api.php?amount=10"
    response = requests.get((url)+str(catagory)+str(difficulty)+str(question_type))
    api_data = json.loads(response.text)
    make_json = open('questions.json','w')
    make_json.write(json.dumps(api_data, ensure_ascii=False, indent = 4))

#this function takes the selected amount of users and creates a acount per user.
def how_many_playing():
    user_amount = int(input('how many users are playing: '))
    #user_amount -=1
    def name_asking():
        username = input('What is Your Users Name: ')
        name_list.append(username)
    for number in range(int(user_amount)):
        name_asking()

#The active user Class.
class Active_user:
    name = None
    correct = 0
    incorrect = 0

#this class takes the user and add the neccesary dat like correct and incorrect values.
class Game:
    user_array=[]


    def add_users(self,data_list:list=None,usernames:list=None) -> None:

        if data_list:
            user_amount = len(data_list)
        else:
            user_amount = len(usernames)
        
        for x in range(user_amount):  
            user = Active_user()
            if data_list != None:
                data = data_list[x]
                user.name=data.get('name')
                user.correct=data.get('correct')
                user.incorrect=data.get('incorrect')
            else:
                user.name=usernames[x]

            self.user_array.append(user)

    def clear_users(self):
        self.user_array.clear()

#this function takes the json ans read the data on it.
def read_data_file(name,filetype='.json'):
    return json.loads(open(name+filetype, "r").read())

#this funtion uses the json file data and formats it into questions witch it asks the user.
def question_function(questions,users): 
    for user in users:
        for counter,  question in enumerate(questions , start=1):
            clear()
            print(user.name +'\n')
            print("questions "+str(counter) + ' of ' + str(len(questions))+'\n')
            print(html.unescape(question["question"])+'\n')
            print("Options:")

            choices = [x for x in question["incorrect_answers"]]
            choices.append(question['correct_answer'])
            random.shuffle(choices)

            for id , items in enumerate(choices, start=1):
                print(str(id) + ' ' + items)
            print('\n')
            user_answer = input_function(len(choices))
            user_answer-=1

            if choices[user_answer] == question['correct_answer']:
                print("Correct!")
                user.correct+=1
            else:
                print("Incorrect. Answer was " + question['correct_answer']) 
                user.incorrect+=1
            time.sleep(1)
        print('result')
        print('name '+user.name)
        print('correct '+str(user.correct))
        print('Incorrect '+str(user.incorrect))
        time.sleep(1)
    clear()
    print("Final score\n")
    for user in users:
        print('Username: '+user.name)
        print('Correct Answers: '+str(user.correct))
        print('Incorrect Answers: '+str(user.incorrect))
        print('\n')

#Main menu function for the code.
def main_menu(catagory = "",difficulty = "",question_type = ""):
    clear()
    print("Main Menu")
    list_print(['Choices','Start Quiz','Quit'])
    user_choice = input_function(3)
    user_choice-=1
    if user_choice == 0:
        clear()
        print("Choose Away")
        time.sleep(0.5)
        choices_menu()
    elif user_choice == 1:
        clear()
        print("Starting Quiz")
        time.sleep(0.5)
        question_grabber(catagory,difficulty,question_type)
        questions = read_data_file('questions')["results"]
        how_many_playing()
        Game().add_users(usernames=name_list)
        users = Game().user_array
        question_function(questions,users)
    elif user_choice == 2:
        clear()
        print("Quitting")
        time.sleep(0.5)
        quit()
    else:
        print("Select a Valid Input")
        time.sleep(1)
        clear()
        main_menu()

#manu function that lets you choose wheter yo want to change catagory difficulty or question type.
def choices_menu():
    clear()
    print("Choises")
    list_print(['Catagory','Difficulty','Question Type'])
    user_choice = input_function(3)
    user_choice-=1
    if user_choice == 0:
        clear()
        print("Select a Catagory")
        time.sleep(0.5)
        catagory_menu()
    elif user_choice == 1:
        clear()
        print("Select a Difficulty")
        time.sleep(0.5)
        difficulty_menu()
    elif user_choice == 2:
        clear()
        print("Select a Question Type")
        time.sleep(0.5)
        question_type_menu()
    else:
        print("Select a Valid Input")
        time.sleep(1)
        clear()
        choices_menu()

#catagory choosing menu.
def catagory_menu():
    clear()
    print("Catagories")
    list_print(['Selecting Science: Computers','Selecting Entertainment: Video Games','Selecting General Knowledge'])
    user_choice = input_function(3)
    user_choice-=1
    if user_choice == 0:
        clear()
        print("Selecting Science: Computers")
        time.sleep(0.5)
        catagory = "&category=18"
        main_menu(catagory)
    elif user_choice == 1:
        clear()
        print("Selecting Entertainment: Video Games")
        time.sleep(0.5)
        catagory = "&category=15"
        main_menu(catagory)
    elif user_choice == 2:
        clear()
        print("Selecting General Knowledge")
        time.sleep(0.5)
        catagory = "&category=9"
        main_menu(catagory)
    else:
        print("Select a Valid Input")
        time.sleep(1)
        clear()
        catagory_menu()

#difficulty choosing menu.
def difficulty_menu():
    clear()
    print("Choises")
    list_print(['Easy','Medium','Hard',"Any"])
    user_choice = input_function(3)
    user_choice-=1
    if user_choice == 0:
        clear()
        print("Selecting Easy")
        time.sleep(0.5)
        difficulty = "&difficulty=easy"
        main_menu(difficulty)
    elif user_choice == 1:
        clear()
        print("Selecting Medium")
        time.sleep(0.5)
        difficulty = "&difficulty=medium"
        main_menu(difficulty)
    elif user_choice == 2:
        clear()
        print("Selecting Hard")
        time.sleep(0.5)
        difficulty = "&difficulty=hard"
        main_menu(difficulty)
    elif user_choice == 3:
        clear()
        print("Selecting Any")
        main_menu(difficulty)
    else:
        print("Select a Valid Input")
        time.sleep(1)
        clear()
        difficulty_menu()

#question type choosing menu.
def question_type_menu():
    clear()
    print("Choises")
    list_print(['Multiple','True/False','Either'])
    user_choice = input_function(3)
    user_choice-=1
    if user_choice == 0:
        print("Selecting Multiple")
        clear()
        time.sleep(0.5)
        question_type = "&type=multiple"
        main_menu(question_type)
    elif user_choice == 1:
        clear()
        print("Selecting True/False")
        time.sleep(0.5)
        question_type = "&type=boolean"
        main_menu(question_type)
    elif user_choice == 2:
        clear()
        print("Selecting Either")
        time.sleep(0.5)
        question_type = ""
        main_menu(question_type)
    else:
        print("Select a Valid Input")
        time.sleep(1)
        clear()
        question_type_menu()

#Checks if the user had internet and returns false if they dont 
def internet(host:str="8.8.8.8", port:int=53, timeout:int=3) -> bool:
    try:
        socket.setdefaulttimeout(timeout)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
        print("Internet Success")
        time.sleep(2)
        main_menu()
        return True
    except socket.error as ex:
        print("Pay your plan")
        return False
    
internet()




